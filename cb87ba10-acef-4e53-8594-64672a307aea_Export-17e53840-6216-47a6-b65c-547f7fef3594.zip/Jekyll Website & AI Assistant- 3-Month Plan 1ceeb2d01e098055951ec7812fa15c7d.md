# Jekyll Website & AI Assistant- 3-Month Plan

# Jekyll Website and AI Assistant: Project Overview

This workspace tracks the development of a professional Jekyll website and the integration of an AI assistant in GitHub over 3 months.

[Master Table Tracker](Master%20Table%20Tracker%201ceeb2d01e09804b8e60ec417485e881.csv)

## Objectives

Phase 1: Jekyll Website & Presentation (Months 1-2)

Create a clean, professional project website using Jekyll and present a value proposition with sponsorship\ donation integration.

[Phase 1-Website Development](https://www.notion.so/Phase-1-Website-Development-1ceeb2d01e0980d5b3b6ca47e94877bc?pvs=21)

Phase 2: GitHub AI Assistance (Month 3)

Design and build an AI assistant to assist with GitHub issues, pull requests, or documentation using OpeneAI and GitHub actions.

[Phase 2: AI Assistant with GitHub Action](https://www.notion.so/Phase-2-AI-Assistant-with-GitHub-Action-1d1eb2d01e098005afecdd5dd38763c6?pvs=21)